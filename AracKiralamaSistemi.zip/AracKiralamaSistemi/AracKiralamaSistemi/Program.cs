﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== ARAÇ KİRALAMA SİSTEMİ ===\n");

            // Araç listesi oluştur
            List<Arac> araclar = new List<Arac>()
            {
                new Otomobil("Toyota", "Corolla", 800, true),
                new Motosiklet("Yamaha", "R6", 500, 650),
                new Kamyon("Mercedes", "Actros", 1200, 12)
            };

            // Müşteri oluştur
            Musteri musteri = new Musteri("Ebru Uyar", "12345678900");

            // Araçları listele
            Console.WriteLine("Mevcut Araçlar:");
            foreach (var a in araclar)
            {
                a.BilgiYazdir();
                Console.WriteLine("----------------");
            }

            // Örnek kiralama işlemi
            Console.WriteLine("\nEbru Uyar bir otomobil kiralıyor...");
            Kiralama kiralama = new Kiralama(musteri, araclar[0], 5);
            kiralama.BilgiYazdir();

            // Ödeme işlemi
            Banka.OdemeYap(kiralama.ToplamTutar);

            // Garbage Collector örneği
            kiralama = null;
            GC.Collect();
            Console.WriteLine("\n[Garbage Collector] Kullanılmayan nesneler temizlendi.");
        }
    }
}