﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal class Kiralama
    {
        public Musteri Musteri { get; set; }
        public Arac Arac { get; set; }
        public int GunSayisi { get; set; }
        public double ToplamTutar { get; private set; }

        public Kiralama(Musteri musteri, Arac arac, int gunSayisi)
        {
            Musteri = musteri;
            Arac = arac;
            GunSayisi = gunSayisi;
            ToplamTutar = arac.UcretHesapla(gunSayisi);
            arac.MusaitMi = false;
        }

        public void BilgiYazdir()
        {
            Musteri.BilgiYazdir();
            Arac.BilgiYazdir();
            Console.WriteLine($"Kiralama Süresi: {GunSayisi} gün");
            Console.WriteLine($"Toplam Ücret: {ToplamTutar}₺\n");
        }
    }
}