﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal class Musteri
    {
        public string AdSoyad { get; set; }
        public string TcNo { get; set; }

        public Musteri(string adSoyad, string tcNo)
        {
            AdSoyad = adSoyad;
            TcNo = tcNo;
        }

        public void BilgiYazdir()
        {
            Console.WriteLine($"Müşteri: {AdSoyad} (TC: {TcNo})");
        }
    }
}