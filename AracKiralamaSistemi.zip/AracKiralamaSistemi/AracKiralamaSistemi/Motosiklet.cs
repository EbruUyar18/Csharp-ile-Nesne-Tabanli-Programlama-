﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal class Motosiklet : Arac
    {
        public int MotorHacmi { get; set; }

        public Motosiklet(string marka, string model, double gunlukUcret, int motorHacmi)
            : base(marka, model, gunlukUcret)
        {
            MotorHacmi = motorHacmi;
        }

        public override double UcretHesapla(int gun)
        {
            double toplam = base.UcretHesapla(gun);
            if (MotorHacmi > 600)
                toplam += 75; // yüksek motor gücü farkı
            return toplam;
        }

        public override void BilgiYazdir()
        {
            base.BilgiYazdir();
            Console.WriteLine($"Motor Hacmi: {MotorHacmi} cc");
        }
    }
}
