﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal class Kamyon : Arac
    {
        public double YukKapasitesi { get; set; }

        public Kamyon(string marka, string model, double gunlukUcret, double yukKapasitesi)
            : base(marka, model, gunlukUcret)
        {
            YukKapasitesi = yukKapasitesi;
        }

        public override double UcretHesapla(int gun)
        {
            double toplam = base.UcretHesapla(gun);
            if (YukKapasitesi > 10)
                toplam += 200; // büyük tonaj farkı
            return toplam;
        }

        public override void BilgiYazdir()
        {
            base.BilgiYazdir();
            Console.WriteLine($"Yük Kapasitesi: {YukKapasitesi} ton");
        }
    }
}