﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal class Otomobil : Arac
    {
        public bool OtomatikVites { get; set; }

        public Otomobil(string marka, string model, double gunlukUcret, bool otomatikVites)
            : base(marka, model, gunlukUcret)
        {
            OtomatikVites = otomatikVites;
        }

        public override double UcretHesapla(int gun)
        {
            double toplam = base.UcretHesapla(gun);
            if (OtomatikVites)
                toplam += 100; // ekstra ücret
            return toplam;
        }

        public override void BilgiYazdir()
        {
            base.BilgiYazdir();
            Console.WriteLine($"Vites Türü: {(OtomatikVites ? "Otomatik" : "Manuel")}");
        }
    }
}