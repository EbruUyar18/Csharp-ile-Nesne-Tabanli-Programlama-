﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal static class Banka
    {
        public static double ToplamGelir { get; private set; }

        public static void OdemeYap(double miktar)
        {
            ToplamGelir += miktar;
            Console.WriteLine($"[Banka] {miktar}₺ ödeme alındı. Güncel gelir: {ToplamGelir}₺");
        }
    }
}