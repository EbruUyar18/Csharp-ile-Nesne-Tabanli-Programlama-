﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracKiralamaSistemi
{
    internal class Arac
    {
        // Property kullanımı
        public string Marka { get; set; }
        public string Model { get; set; }
        public double GunlukUcret { get; set; }
        public bool MusaitMi { get; set; }

        // Kurucu metot
        public Arac(string marka, string model, double gunlukUcret)
        {
            Marka = marka;
            Model = model;
            GunlukUcret = gunlukUcret;
            MusaitMi = true;
        }

        // Sanal (virtual) metot – çok biçimlilik için temel sağlar
        public virtual double UcretHesapla(int gun)
        {
            return GunlukUcret * gun;
        }

        // Bilgi yazdırma fonksiyonu
        public virtual void BilgiYazdir()
        {
            Console.WriteLine($"{Marka} {Model} - Günlük Ücret: {GunlukUcret}₺ - {(MusaitMi ? "Müsait" : "Kirada")}");
        }
    }
}